Wings N Things brand files

Wordmark font: Space Grotesk Bold (free, SIL Open Font License) - https://fonts.google.com/specimen/Space+Grotesk
Mark: "Flight Bars" - three swept bars (#1c1917) on an amber tile (#f59e0b).

wings-n-things-logo-email.png      - 520px wide, transparent. Use in email signatures (~200px display width).
wings-n-things-logo.png            - 1040px wide, transparent. Print / high-DPI.
wings-n-things-logo-white-text.png - for dark backgrounds.
wings-n-things-mark-*.png          - the square tile alone, 64 to 1024px (avatars, favicons, social).
*.svg                              - vector masters; the lockup SVGs need Space Grotesk installed to edit.