Wings N Things brand files

wings-n-things-logo-email.png   - 520px wide, transparent. Use this one in email signatures.
wings-n-things-logo.png         - 1040px wide, transparent. Print / high-DPI.
wings-n-things-logo-white-text.png - for dark backgrounds.
wings-n-things-mark-*.png       - the square tile alone, 64 to 1024px (avatars, favicons, social).
*.svg                           - vector masters; scale to any size without loss.